

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>first_name</th>
                        <th>last_name</th>
                        <th>birthday</th>
                        <th>gender</th>
                        <th>place_of_birth</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                        <tr>
                            <td><?php echo e($author['first_name']); ?></td>
                            <td><?php echo e($author['last_name']); ?></td>
                            <td><?php echo e($author['birthday']); ?></td>
                            <td><?php echo e($author['gender']); ?></td>
                            <td><?php echo e($author['place_of_birth']); ?></td>
                            <td><a href="/author/<?php echo e($author['id']); ?>">Detail</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\royal-apps\resources\views/authors/authors.blade.php ENDPATH**/ ?>