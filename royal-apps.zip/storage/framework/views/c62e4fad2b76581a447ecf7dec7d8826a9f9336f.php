

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>email</th>
                        <th>first_name</th>
                        <th>last_name</th>
                        <th>gender</th>
                       
                         
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($user['email']); ?></td>
                        <td><?php echo e($user['first_name']); ?></td>
                        <td><?php echo e($user['last_name']); ?></td>
                        <td><?php echo e($user['gender']); ?></td>
                      
                         
                        <?php if(empty($author['books'])): ?>
                        <td><a href="#">DELETE</a></td>
                    <?php endif; ?>
                    </tr>
                </tbody>
            </table>
             
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\royal-apps\resources\views/profile.blade.php ENDPATH**/ ?>