

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card-body">
                <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                <form method="POST" action="<?php echo e(route('book')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label for="title" class="col-md-4 col-form-label text-md-end">author</label>
                        <div class="col-md-6">
                             <select name="author" required>
                                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($author["id"]); ?>" ><?php echo e($author["first_name"]); ?> <?php echo e($author["last_name"]); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="title" class="col-md-4 col-form-label text-md-end">title</label>
                        <div class="col-md-6">
                            <input id="title" type="text" class="form-control" name="title" value="" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="description" class="col-md-4 col-form-label text-md-end">description</label>
                        <div class="col-md-6">
                            <input id="description" type="text" class="form-control" name="description" value="" >
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <label for="release_date" class="col-md-4 col-form-label text-md-end">release_date</label>
                        <div class="col-md-6">
                            <input id="release_date" type="date" class="form-control" name="release_date" value="" >
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="isbn" class="col-md-4 col-form-label text-md-end">isbn</label>
                        <div class="col-md-6">
                            <input id="isbn" type="text" class="form-control" name="isbn" value="" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="format" class="col-md-4 col-form-label text-md-end">format</label>
                        <div class="col-md-6">
                            <input id="format" type="text" class="form-control" name="format" value="" >
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="number_of_pages" class="col-md-4 col-form-label text-md-end">number_of_pages</label>
                        <div class="col-md-6">
                            <input id="number_of_pages" type="number" class="form-control" name="number_of_pages" value="" >
                        </div>
                    </div>
                     
                    <input type="submit" value="create">
                    
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\royal-apps\resources\views/authors/books/create.blade.php ENDPATH**/ ?>