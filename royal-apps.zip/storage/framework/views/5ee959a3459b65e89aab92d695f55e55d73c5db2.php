

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>first_name</th>
                        <th>last_name</th>
                        <th>birthday</th>
                        <th>gender</th>
                        <th>place_of_birth</th>
                         
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($author['first_name']); ?></td>
                        <td><?php echo e($author['last_name']); ?></td>
                        <td><?php echo e($author['birthday']); ?></td>
                        <td><?php echo e($author['gender']); ?></td>
                        <td><?php echo e($author['place_of_birth']); ?></td>
                         
                        <?php if(empty($author['books'])): ?>
                        <td><a href="#">DELETE</a></td>
                    <?php endif; ?>
                    </tr>
                </tbody>
            </table>
             
            <?php if(!empty($author['books'])): ?>
            <h2>BOOKS</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>title</th>
                        <th>release_date</th>
                        <th>description</th>
                        <th>isbn</th>
                        <th>number_of_pages</th>
                         
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $author['books']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($title['title']); ?></td>
                        <td><?php echo e($title['release_date']); ?></td>
                        <td><?php echo e($title['description']); ?></td>
                        <td><?php echo e($title['isbn']); ?></td>
                        <td><?php echo e($title   ['number_of_pages']); ?></td> 
                        <td><a href="#">DELETE</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\royal-apps\resources\views/authors/author_detail.blade.php ENDPATH**/ ?>